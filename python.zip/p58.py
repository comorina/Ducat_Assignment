l=[21,32,43,45,67,76,87,78,99]
l.sort()
print(l[-1])
print(max(l))
