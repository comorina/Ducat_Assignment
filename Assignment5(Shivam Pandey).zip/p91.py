def evenOdd(x):
    if(x%2==0):
        print(x," is Even number")
    else:
        print(x," is Odd number")

evenOdd(5)
