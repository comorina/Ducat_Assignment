l=['red','green','white','black','pink','yellow']
l.remove(l[0])
l.remove(l[3])
l.remove(l[3])
print(l)
