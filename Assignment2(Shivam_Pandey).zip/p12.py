n = int(input("Enter a number : "))

if(n%2==0):
    print("Even!")
else:
    print("Odd!")

if(n<0):
    print("Negative number")
else:
    print("Positive number")
    
