w = int(input("Enter the width : "))
l = int(input("Enter the length : "))
area = w*l
print("Area of ractangle : ",area)

r =int(input("Enter the radius of Circle : "))
c_area = (22/7)*(r**2)
print("Area of Circle : ",c_area)
