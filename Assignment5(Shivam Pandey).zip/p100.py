def power(a,b):
    return (a**b)
p=power(int(input()),int(input()))
print('Power : ',p)
