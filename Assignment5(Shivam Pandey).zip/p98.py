def greaterNumber(x,y):
    if(x>y):
        print('{} is  greater than {}'.format(x,y))
    else:
        print('{} is  greater than {}'.format(y,x))
    return None
greaterNumber(int(input()),int(input()))
