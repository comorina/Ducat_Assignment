a= int(input("Enter 1st number : "))
b= int(input("Enter 2nd number : "))

print("Addition of two number : ",a+b)
print("Subtraction of two number : ",a-b)
print("Division of two number : ",a/b)
print("Multiplication of two number : ",a*b)
print("Inverse of 1st number : ",1/a)
print("Inverse of 2nd number : ",1/b)
