def sum(x,y):
    
    return (x+y)
add=sum(int(input()),int(input()))
print('Addition: ',add)
