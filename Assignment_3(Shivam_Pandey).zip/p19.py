print("Even numbers : ")
for i in range(100,1,-1):
    if(i%2==0):
        print(i, end=" ")
print("\nOdd numbers : ")
for i in range(100,1,-1):
    if(i%2!=0):
        print(i, end=" ")
