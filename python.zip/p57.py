l=[1,2,3,4,5,6,7,8,9,10]
x=0
for i in l:
    x=x+i
print(x)
sum=sum(l)
print(sum)
