for i in range(1, 10):
    sum = ((i+1)*(2*i+1))/6
print("Sum of 1^2 + 2^2+ 3^2+ ...+10^2 : ", sum)

