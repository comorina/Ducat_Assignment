l=['s','h','i','v','a','m']
str=''
print(str.join(l))
for i in l:
    str+=i
print(str)
