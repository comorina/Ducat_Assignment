l=['abc','xyz','aba','1221']
count=0
for i in l:
    if(len(i)>2):
        if(i[-1]==i[0]):
            count+=1
print(count)
