def rev(x):
    while(x>0):
        re=x%10
        x=x//10
        print(re,end='')
rev(int(input("Enter number : ")))
   
               
               
