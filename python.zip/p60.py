l=[21,34,21,44,56,55,33]
l.remove(21)
print(l)

count=l.count(21)
print(count)
