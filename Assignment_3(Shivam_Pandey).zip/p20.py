sum = 0
for i in range(1,100):
    sum = sum +i
print("Sum of 1 to 100 : ", sum)    
